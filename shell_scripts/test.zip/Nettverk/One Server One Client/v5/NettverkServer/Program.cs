﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace NettverkServer
{
    class Program
    {
        static SocketServer myServer = new SocketServer();
        static void Main(string[] args)
        {
            myServer.RunServer(8113);
            //now that we have a connection and it is launched
            Thread ReceiveThread = new Thread(new ThreadStart(ServerReceive));
            ReceiveThread.Name = "myServerRecThread";
            ReceiveThread.Start();

            while (true)
                Thread.Sleep(10);
        }
        static private void ServerReceive()
        {
            while (true)
                if (myServer.IsSending() == false)
                    myServer.Receive();
        }
    }
}
