﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;

namespace NettverkServer
{
    class SocketServer
    {
        // Data buffer for incoming data. 
        public const int bufferLength = 1024;
        private byte[] bytes = new byte[bufferLength];
        private string data = null;

        private Socket listener;
        private Socket handler;
        private IPEndPoint localEndPoint;

        private bool Sending = false;
        public bool IsSending()
        {
            return Sending;
        }

        public void RunServer(int port)
        {
            // Establish the local endpoint for the socket.  
            // Dns.GetHostName returns the name of the   
            // host running the application.  
            IPHostEntry ipHostInfo = Dns.GetHostEntry(Dns.GetHostName());
            IPAddress ipAddress = ipHostInfo.AddressList[0];
            localEndPoint = new IPEndPoint(ipAddress, port); 

            // Create a TCP/IP socket.  
            listener = new Socket(ipAddress.AddressFamily,
                SocketType.Stream, ProtocolType.Tcp);

            Listen();//will pause here until accepted connection is made
        }

        private void Listen()
        {
            try
            {
                listener.Bind(localEndPoint);
                listener.Listen(10);

                while (true)
                {
                    Console.WriteLine("Waiting for a connection...");
                    // Program is suspended while waiting for an incoming connection.  
                    handler = listener.Accept();

                    ReceiveAndEcho();
                    break;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
        }
        private void ReceiveAndEcho()
        {
            byte[] rec = Receive();
            Send(rec);
        }
        public byte[] Receive()
        {
            data = null;
            Console.WriteLine("Waiting for data...");// An incoming connection needs to be processed.  
            while (true)
            {
                try
                {
                    bytes = new byte[bufferLength];
                    int bytesRec = handler.Receive(bytes);
                    data += Encoding.ASCII.GetString(bytes, 0, bytesRec);
                    if (data.IndexOf("<EOF>") > -1)
                    {
                        break;
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.ToString());
                }
            }

            // Show the data on the console.  
            Console.WriteLine("Text received : {0}", data);

            // Echo the data back to the client.  
            byte[] msg = Encoding.ASCII.GetBytes(data);
            //now obliterate data
            data = null;
            return msg;
        }
        public void Send(byte[] message)
        {
            Sending = true;
            handler.Send(message);
            Console.WriteLine("Server has sent");
            Sending = false;
        }
        public void Send(string message)
        {
            Sending = true;
            byte[] msg = Encoding.ASCII.GetBytes(message + "<EOF>");
            handler.Send(msg);
            Sending = false;
            Console.WriteLine("Server has sent");
        }
        public void StopServer()
        {
            handler.Shutdown(SocketShutdown.Both);
            handler.Close();
        }
    }
}