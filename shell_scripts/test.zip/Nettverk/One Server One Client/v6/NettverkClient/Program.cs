﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace NettverkClient
{
    class Program
    {
        static void Main(string[] args)
        {
            NetHandler.RunClient("127.0.0.1", 8113);

            while (true)
            {
                //send custom message
                Console.WriteLine("What is it you want to say?");
                string message = Console.ReadLine();
                NetHandler.Send(message);
            }
        }
    }
}
