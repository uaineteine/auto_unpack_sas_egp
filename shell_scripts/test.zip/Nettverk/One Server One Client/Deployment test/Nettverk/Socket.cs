﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Nettverk
{
    public class NettverkSocket
    {
        bool Server;
        public bool Killing = false;
        public bool ThreadClosed = false;
        NettverkServer.SocketServer myServer = new NettverkServer.SocketServer();
        NettverkClient.SocketClient myClient = new NettverkClient.SocketClient();
        public NettverkSocket(string ip, int port, bool intent)
        {
            Server = intent;
        }
        public NettverkSocket(int port, bool intent)
        {
            Server = intent;
        }
        public bool IsSending()
        {
            if (Server == true)
                return myServer.IsSending();
            else
                return myClient.IsSending();
        }
        public void RunServer()
        {
            myServer.RunServer(8113);
        }
        public void RunClient(string ip, int port)
        {
            myClient.RunClient(ip, 8113);
        }
        public void Send(string msg, string type)
        {
            if (Server == true)
                myServer.Send(msg, type);
            else
                myClient.Send(msg, type);
        }
        public string Receive()
        {
            if (Server == true)
                return Encoding.ASCII.GetString(myServer.Receive());
            else
                return myClient.Receive();
        }
    }
}