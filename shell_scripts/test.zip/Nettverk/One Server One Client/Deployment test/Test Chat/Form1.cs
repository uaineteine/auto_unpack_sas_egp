﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Nettverk;

namespace Test_Chat
{
    public partial class Form1 : Form
    {
        NettverkSocket socket;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            socket = new NettverkSocket(8113, true);
            socket.RunServer();
            socket.Send("test", "00");
            //now that we have a connection and it is launched
            Thread ReceiveThread = new Thread(new ThreadStart(socketReceive));
            ReceiveThread.Name = "myServerRecThread";
            ReceiveThread.Start();
        }
        private void socketReceive()
        {
            while (true)
            {
                if (socket.IsSending() == false)
                {
                    string msg = socket.Receive();
                    if (msg != "")
                    {
                        string strype = msg.Remove(2, msg.Length - 2);
                        int type = Convert.ToInt32(strype);
                        msg = msg.Remove(0, 5);
                        HandleMessage(type, msg);
                    }
                }
                if (socket.Killing == true)
                {
                    //terminate
                    socket.ThreadClosed = true;
                    Thread.CurrentThread.Abort();
                }
            }
        }

        private void HandleMessage(int type, string msg)
        {
            switch(type)
            {
                case 0:
                    break;//do nothing
                case 1:
                    richTextBox1.Text += msg;
                    break;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            socket.Send(richTextBox2.Text, "01");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            socket = new NettverkSocket(textBox1.Text, 8113, false);
            socket.RunClient(textBox1.Text, 8113);
            //now that we have connected and said hello let us get the receiving thread going
            Thread myClientReceiveThread = new Thread(new ThreadStart(socketReceive));
            myClientReceiveThread.Name = "myClientReceiveThread";
            myClientReceiveThread.Start();
        }
    }
}
