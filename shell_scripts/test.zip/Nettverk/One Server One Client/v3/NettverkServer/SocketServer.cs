﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;

namespace NettverkServer
{
    class SocketServer
    {
        // Data buffer for incoming data. 
        public const int bufferLength = 1024;
        private byte[] bytes = new byte[bufferLength];
        private string data = null;

        private Socket listener;
        private Socket handler;
        private IPEndPoint localEndPoint;

        public void RunServer(int port)
        {
            // Establish the local endpoint for the socket.  
            // Dns.GetHostName returns the name of the   
            // host running the application.  
            IPHostEntry ipHostInfo = Dns.GetHostEntry(Dns.GetHostName());
            IPAddress ipAddress = ipHostInfo.AddressList[0];
            localEndPoint = new IPEndPoint(ipAddress, port); 

            // Create a TCP/IP socket.  
            listener = new Socket(ipAddress.AddressFamily,
                SocketType.Stream, ProtocolType.Tcp);

            Listen();
        }

        private void Listen()
        {
            try
            {
                listener.Bind(localEndPoint);
                listener.Listen(10);

                while (true)
                {
                    Console.WriteLine("Waiting for a connection...");
                    // Program is suspended while waiting for an incoming connection.  
                    handler = listener.Accept();
                    data = null;
                    while (true) //this is always recieve bit
                    {
                        Console.WriteLine("Waiting for data...");// An incoming connection needs to be processed.  
                        while (true)
                        {
                            bytes = new byte[1024];
                            int bytesRec = handler.Receive(bytes);
                            data += Encoding.ASCII.GetString(bytes, 0, bytesRec);
                            if (data.IndexOf("<EOF>") > -1)
                            {
                                break;
                            }
                        }

                        // Show the data on the console.  
                        Console.WriteLine("Text received : {0}", data);

                        // Echo the data back to the client.  
                        byte[] msg = Encoding.ASCII.GetBytes(data);
                        //now obliterate data
                        data = null;

                        handler.Send(msg);
                        Console.WriteLine("Server has responded with the same message");
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }

            Console.WriteLine("\nPress ENTER to continue...");
            Console.Read();
        }
        public void StopServer()
        {
            handler.Shutdown(SocketShutdown.Both);
            handler.Close();
        }
    }
}