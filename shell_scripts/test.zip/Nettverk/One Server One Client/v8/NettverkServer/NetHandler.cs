﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Net;
using System.Net.Sockets;

namespace NettverkServer
{
    public static class NetHandler
    {
        static SocketServer myServer = new SocketServer();
        public static void RunServer()
        {
            myServer.RunServer(8113);
            //now that we have a connection and it is launched
            Thread ReceiveThread = new Thread(new ThreadStart(ServerReceive));
            ReceiveThread.Name = "myServerRecThread";
            ReceiveThread.Start();
        }
        public static void Send(string msg)
        {
            myServer.Send(msg);
        }
        static private void ServerReceive()
        {
            while (true)
                if (myServer.IsSending() == false)
                    myServer.Receive();
        }
    }
}
