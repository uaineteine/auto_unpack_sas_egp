﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace NettverkClient
{
    public static class NetHandler
    {
        static SocketClient myClient = new SocketClient();
        public static void RunClient(string ip, int port)
        {
            myClient.RunClient(ip, 8113);
            //now that we have connected and said hello let us get the receiving thread going
            Thread myClientReceiveThread = new Thread(new ThreadStart(ClientReceive));
            myClientReceiveThread.Name = "myClientReceiveThread";
            myClientReceiveThread.Start();
        }
        public static void GracefulDisconnect()
        {
            //Need to disconnect from both ends and thus remove our receive thread
        }
        public static void Send(string msg)
        {
            myClient.Send(msg);
        }
        static void ClientReceive()
        {
            while (true)
                if (myClient.IsSending() == false)
                    Console.WriteLine(myClient.Receive());
        }
    }
}
