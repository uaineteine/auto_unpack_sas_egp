﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;

namespace NettverkClient
{
    class Program
    {
        static SocketClient myClient = new SocketClient();
        static void Main(string[] args)
        {
            myClient.RunClient(8113);
        }

    }
}
