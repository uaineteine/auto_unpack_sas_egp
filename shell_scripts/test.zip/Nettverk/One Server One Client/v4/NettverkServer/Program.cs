﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;

namespace NettverkServer
{
    class Program
    {
        static SocketServer myServer = new SocketServer();
        static void Main(string[] args)
        {
            myServer.RunServer(8113);
        }
    }
}
