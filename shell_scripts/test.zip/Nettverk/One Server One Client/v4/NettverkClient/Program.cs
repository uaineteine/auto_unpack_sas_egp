﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;

namespace NettverkClient
{
    class Program
    {
        static SocketClient myClient = new SocketClient();
        static void Main(string[] args)
        {
            myClient.RunClient(8113);
            //now that we have connected and said hello send some more stuff
            myClient.Send("Testing");
            myClient.Send("TestingAgain");
            myClient.Send("TestingAgainAgain");

            while (true)
            {
                //send custom message
                Console.WriteLine("What is it you want to say?");
                string message = Console.ReadLine();
                myClient.Send(message);
            }
        }

    }
}
